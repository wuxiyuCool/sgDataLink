import{R as o,C as r}from"./index.7643f9a4.js";import{aN as a}from"./index.a15e30bf.js";var l=a(o),m=a(r);export{m as C,l as R};
