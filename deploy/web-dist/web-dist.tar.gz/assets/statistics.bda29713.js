import{cI as t}from"./index.89abe709.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
