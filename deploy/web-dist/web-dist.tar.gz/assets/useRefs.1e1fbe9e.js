import{s as n,cl as a}from"./index.558eda99.js";var t=function(){var e=n(new Map),r=function(s){return function(f){e.value.set(s,f)}};return a(function(){e.value=new Map}),[r,e]},c=t;export{c as u};
