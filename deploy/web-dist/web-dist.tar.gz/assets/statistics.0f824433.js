import{cI as t}from"./index.1d5a305e.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
