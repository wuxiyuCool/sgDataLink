import{d as t}from"./http.a0398419.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
