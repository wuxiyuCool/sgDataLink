import{R as o,C as r}from"./index.361b817a.js";import{aN as a}from"./index.ae8aa64b.js";var l=a(o),m=a(r);export{m as C,l as R};
