import{aw as t,G as r}from"./index.447874a7.js";function o(a){var e=t();return r(function(){e.value=a()},{flush:"sync"}),e}export{o as e};
