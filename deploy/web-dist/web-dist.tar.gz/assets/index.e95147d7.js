import{R as o,C as r}from"./index.5fcc771a.js";import{aN as a}from"./index.adf34700.js";var l=a(o),m=a(r);export{m as C,l as R};
