import{s as a,Y as r,aT as t}from"./index.a15e30bf.js";var u=function(){var e=a(!1);return r(function(){e.value=t()}),e};export{u};
