import{cI as t}from"./index.3edc04b8.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
