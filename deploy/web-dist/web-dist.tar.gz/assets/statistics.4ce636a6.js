import{cI as t}from"./index.e46e11c5.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
