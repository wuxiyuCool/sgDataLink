import{aw as t,G as r}from"./index.2ef08082.js";function o(a){var e=t();return r(function(){e.value=a()},{flush:"sync"}),e}export{o as e};
