import{aw as t,G as r}from"./index.1d5a305e.js";function o(a){var e=t();return r(function(){e.value=a()},{flush:"sync"}),e}export{o as e};
