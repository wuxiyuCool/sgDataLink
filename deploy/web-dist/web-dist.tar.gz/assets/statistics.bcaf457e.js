import{cI as t}from"./index.a15e30bf.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
