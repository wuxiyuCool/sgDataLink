import{cI as t}from"./index.ae8aa64b.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
