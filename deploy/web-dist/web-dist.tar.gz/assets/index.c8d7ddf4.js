import{R as o,C as r}from"./index.a7e897a6.js";import{aN as a}from"./index.234f404a.js";var l=a(o),m=a(r);export{m as C,l as R};
