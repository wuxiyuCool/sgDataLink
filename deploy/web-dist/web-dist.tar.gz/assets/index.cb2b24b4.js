import{R as o,C as r}from"./index.f2d02b1d.js";import{aN as a}from"./index.2ef08082.js";var l=a(o),m=a(r);export{m as C,l as R};
