import{R as o,C as r}from"./index.5de88084.js";import{aN as a}from"./index.4de90ad4.js";var l=a(o),m=a(r);export{m as C,l as R};
