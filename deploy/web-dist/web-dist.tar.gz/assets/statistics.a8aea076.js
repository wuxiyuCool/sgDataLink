import{d as t}from"./http.b0041f69.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
