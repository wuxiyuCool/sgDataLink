import{R as o,C as r}from"./index.ba2e8a54.js";import{aN as a}from"./index.66ecba07.js";var l=a(o),m=a(r);export{m as C,l as R};
