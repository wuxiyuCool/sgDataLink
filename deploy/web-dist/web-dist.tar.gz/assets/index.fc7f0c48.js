import{R as o,C as r}from"./index.edccd9de.js";import{aN as a}from"./index.32eefdeb.js";var l=a(o),m=a(r);export{m as C,l as R};
