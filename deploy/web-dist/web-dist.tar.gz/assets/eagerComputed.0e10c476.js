import{aw as t,G as r}from"./index.ae8aa64b.js";function o(a){var e=t();return r(function(){e.value=a()},{flush:"sync"}),e}export{o as e};
