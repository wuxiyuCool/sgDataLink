import{cI as t}from"./index.447874a7.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
