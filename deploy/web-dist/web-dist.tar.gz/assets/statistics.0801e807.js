import{cI as t}from"./index.4de90ad4.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
