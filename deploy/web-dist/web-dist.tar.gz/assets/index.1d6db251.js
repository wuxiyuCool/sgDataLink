import{R as o,C as r}from"./index.2d460f02.js";import{aN as a}from"./index.0a042a42.js";var l=a(o),m=a(r);export{m as C,l as R};
