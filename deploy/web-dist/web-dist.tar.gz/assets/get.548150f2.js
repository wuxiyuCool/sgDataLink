import{ah as u}from"./index.a15e30bf.js";function d(e,r,t){var n=e==null?void 0:u(e,r);return n===void 0?t:n}export{d as g};
