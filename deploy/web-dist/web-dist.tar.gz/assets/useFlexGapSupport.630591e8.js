import{s as a,Y as r,aT as t}from"./index.c9919aa0.js";var u=function(){var e=a(!1);return r(function(){e.value=t()}),e};export{u};
