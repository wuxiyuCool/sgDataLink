import{cI as t}from"./index.66ecba07.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
