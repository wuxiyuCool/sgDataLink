import{ah as u}from"./index.558eda99.js";function d(e,r,t){var n=e==null?void 0:u(e,r);return n===void 0?t:n}export{d as g};
