import{cI as t}from"./index.2ef08082.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
