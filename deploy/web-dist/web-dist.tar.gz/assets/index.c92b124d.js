import{R as o,C as r}from"./index.3005e411.js";import{aN as a}from"./index.558eda99.js";var l=a(o),m=a(r);export{m as C,l as R};
