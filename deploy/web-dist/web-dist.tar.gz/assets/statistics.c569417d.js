import{cI as t}from"./index.c9919aa0.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
