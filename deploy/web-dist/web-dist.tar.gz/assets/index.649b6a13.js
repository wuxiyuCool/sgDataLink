import{R as o,C as r}from"./index.f8509f5f.js";import{aN as a}from"./index.a7439746.js";var l=a(o),m=a(r);export{m as C,l as R};
