import{cI as t}from"./index.a7439746.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
