import{cI as t}from"./index.234f404a.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
