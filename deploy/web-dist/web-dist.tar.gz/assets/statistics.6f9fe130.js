import{cI as t}from"./index.adf34700.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
