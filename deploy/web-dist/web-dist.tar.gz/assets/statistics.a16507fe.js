import{cI as t}from"./index.0a042a42.js";function e(){return t.get({url:"/statistics/overview"})}export{e as g};
